import {
  Controller,
  Post,
  Get,
  Patch,
  Delete,
  Param,
  Body,
} from '@nestjs/common';


import { CreateNutritionPlanDto } from './dtos/create-nutrition-plan.dto';
import { UpdateNutritionPlanDto } from './dtos/update-nutrition-plan.dto';
import { NutritionService } from './nutrition.service';


@Controller('nutrition-plans')
export class NutritionController {
  constructor(private readonly service: NutritionService) {}

  /* =========================
     CREATE
  ========================== */
  @Post(':professionalId')
  create(
    @Param('professionalId') professionalId: string,
    @Body() dto: CreateNutritionPlanDto,
  ) {
    return this.service.create(dto, professionalId);
  }

  /* =========================
     FIND BY USER
  ========================== */
  @Get('user/:userUuid')
  findByUser(@Param('userUuid') userUuid: string) {
    return this.service.findByUser(userUuid);
  }

  /* =========================
     FIND ONE
  ========================== */
  @Get(':uuid')
  findOne(@Param('uuid') uuid: string) {
    return this.service.findOne(uuid);
  }

  /* =========================
     UPDATE
  ========================== */
  @Patch(':uuid')
  update(
    @Param('uuid') uuid: string,
    @Body() dto: UpdateNutritionPlanDto,
  ) {
    return this.service.update(uuid, dto);
  }

  /* =========================
     DELETE (SOFT)
  ========================== */
  @Delete(':uuid')
  deactivate(@Param('uuid') uuid: string) {
    return this.service.deactivate(uuid);
  }
}

import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';

import { Order, OrderStatus } from 'src/entities/order.entity';
import { OrderRepository } from './order.repository';
import { CartRepository } from 'src/cart/cart.repository';
import { OrderDetail } from 'src/entities/order_detail.entity';
import { OrderDetailRepository } from 'src/orderdetail/orderdetail.repository';
import { UpdateOrderDto } from './dtos/update-order.dto';


@Injectable()
export class OrderService {
  constructor(
    private readonly orderRepository: OrderRepository,
    private readonly cartRepository: CartRepository,
    private readonly orderDetailRepository: OrderDetailRepository,
  ) {}

  // =========================
  // ADMIN
  // =========================

  getAllOrdersService() {
    return this.orderRepository.getAllOrdersRepository();
  }

  async putOrderStatusService(uuid: string, dto: UpdateOrderDto) {
    const order = await this.orderRepository.getOrderByIdRepository(uuid);
    if (!order) throw new NotFoundException('Orden no encontrada.');

    return this.orderRepository.putUpdateOrderStatusRepository(order, dto);
  }

  async deleteOrderService(uuid: string) {
    const order = await this.orderRepository.getOrderByIdRepository(uuid);
    if (!order) throw new NotFoundException('Orden no encontrada.');

    return this.orderRepository.deleteOrderRepository(order);
  }

  // =========================
  // USER
  // =========================

  async postCreateOrderService(req: any) {
    const userUuid = req.user.user_uuid;

    // 🔧 FIX 1: método correcto
    const cart =
      await this.cartRepository.getCartByUserIdRepository(userUuid);

    // 🔧 FIX 2: nombre correcto de la relación
    if (!cart || cart.cartDetails.length === 0) {
      throw new BadRequestException('Carrito vacío.');
    }

    const subtotal = cart.cartDetails.reduce(
      (sum, d) => sum + d.unitPrice * d.quantity,
      0,
    );

    const iva = subtotal * 0.19;
    const deliveryCost = 4000;

    const order = new Order();
    order.user = { uuid: userUuid } as any;
    order.subtotal = subtotal;
    order.discount = 0;
    order.iva = iva;
    order.deliveryCost = deliveryCost;
    order.total = subtotal + iva + deliveryCost;
    order.status = OrderStatus.CREATED;

    const savedOrder =
      await this.orderRepository.postCreateOrderRepository(order);

    const details = cart.cartDetails.map((d) => {
      const od = new OrderDetail();
      od.order = savedOrder;
      od.product = d.product;
      od.quantity = d.quantity;
      od.unitPrice = d.unitPrice;
      od.subtotal = d.unitPrice * d.quantity; // ✔ más seguro
      return od;
    });

await this.orderDetailRepository.postCreateOrderDetailsRepository(details);

await this.cartRepository.completeCart(cart);
await this.cartRepository.clearCart(cart);


return {
  message: 'Orden creada correctamente.',
  order: savedOrder,
};

  }

  getOrdersHistoryService(req: any) {
    return this.orderRepository.getOrdersHistoryRepository(
      req.user.user_uuid,
    );
  }

  async putCancelOrderService(req: any, uuid: string) {
    const order = await this.orderRepository.getOrderByIdRepository(uuid);
    if (!order) throw new NotFoundException('Orden no encontrada.');

    if (order.user.uuid !== req.user.user_uuid) {
      throw new ForbiddenException('No puedes cancelar esta orden.');
    }

    if (order.status === OrderStatus.CANCELED) {
      throw new ConflictException('La orden ya está cancelada.');
    }

    if (
      order.status !== OrderStatus.CREATED &&
      order.status !== OrderStatus.PAID
    ) {
      throw new BadRequestException(
        'No se puede cancelar una orden en este estado.',
      );
    }

    return this.orderRepository.putCancelOrderRepository(order);
  }

  // =========================
  // SHARED
  // =========================

  async getOrderByIdService(uuid: string, req: any) {
    const order = await this.orderRepository.getOrderByIdRepository(uuid);
    if (!order) throw new NotFoundException('Orden no encontrada.');

    const isAdmin = req.user.role === 'ADMIN';
    const isOwner = order.user.uuid === req.user.user_uuid;

    if (!isAdmin && !isOwner) {
      throw new ForbiddenException('No tienes permisos.');
    }

    return order;
  }
}

import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Order } from '../entities/order.entity';
import { OrderService } from './order.service';
import { OrderController } from './order.controller';
import { OrderRepository } from './order.repository';
import { CartModule } from 'src/cart/cart.module';
import { UserModule } from 'src/users/users.module';
import { OrderDetailModule } from 'src/orderdetail/orderdetail.module';
import { CartDetail } from 'src/entities/cartDetail.entity';



@Module({
  imports: [
    TypeOrmModule.forFeature([Order]),
    UserModule,
    CartModule,
    CartDetail,
    forwardRef(() => OrderDetailModule),
  ],
  controllers: [OrderController],
  providers: [OrderService, OrderRepository],
  exports: [OrderRepository],
})
export class OrderModule {}


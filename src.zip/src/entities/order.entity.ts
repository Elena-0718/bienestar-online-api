import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  OneToMany,
  OneToOne,
  CreateDateColumn,
  UpdateDateColumn,
  JoinColumn,
  Index,
} from 'typeorm';

import { User } from './users.entity';
import { OrderDetail } from './order_detail.entity';
import { Payment } from './payment.entity';
import { Delivery } from './delivery.entity';

/* =========================
   ENUM ESTADO DE ORDEN
========================== */
export enum OrderStatus {
  CREATED = 'CREATED',
  PAID = 'PAID',
  SHIPPED = 'SHIPPED',
  DELIVERED = 'DELIVERED',
  CANCELED = 'CANCELED',
}

@Entity({ name: 'orders' })
@Index(['user'])
@Index(['status'])
@Index(['createdAt'])
export class Order {
  /* =========================
     IDENTIFICACIÓN
  ========================== */

  @PrimaryGeneratedColumn('uuid')
  uuid: string;

  /* =========================
     MONTOS
  ========================== */

  @Column({
    type: 'decimal',
    precision: 10,
    scale: 2,
    nullable: false,
    comment: 'Suma de los subtotales de los productos',
  })
  subtotal: number;

  @Column({
    type: 'decimal',
    precision: 10,
    scale: 2,
    default: 0,
    comment: 'Descuento aplicado a la orden',
  })
  discount: number;

  @Column({
    type: 'decimal',
    precision: 10,
    scale: 2,
    nullable: false,
    comment: 'Valor del IVA aplicado',
  })
  iva: number;

  @Column({
    type: 'decimal',
    precision: 10,
    scale: 2,
    default: 0,
    comment: 'Costo del envío',
  })
  deliveryCost: number;

  @Column({
    type: 'decimal',
    precision: 10,
    scale: 2,
    nullable: false,
    comment: 'Total final de la orden',
  })
  total: number;

  /* =========================
     ESTADO
  ========================== */

  @Column({
    type: 'enum',
    enum: OrderStatus,
    default: OrderStatus.CREATED,
  })
  status: OrderStatus;

  /* =========================
     RELACIONES
  ========================== */

  /**
   * Usuario que realizó la compra
   * Las órdenes NO se eliminan si se borra el usuario
   */
  @ManyToOne(() => User, (user) => user.orders, {
    nullable: false,
    onDelete: 'RESTRICT',
  })
  @JoinColumn({ name: 'user_uuid' })
  user: User;

  /**
   * Detalles de la orden
   */
  @OneToMany(() => OrderDetail, (detail) => detail.order, {
    cascade: ['insert'],
  })
  orderDetails: OrderDetail[];

  /**
   * Pago asociado a la orden
   */
  @OneToOne(() => Payment, (payment) => payment.order, {
    nullable: false,
    cascade: ['insert'],
  })
  payment: Payment;

  /**
   * Información de entrega
   */
  @OneToOne(() => Delivery, (delivery) => delivery.order, {
    nullable: false,
    cascade: ['insert'],
  })
  delivery: Delivery;

  /* =========================
     AUDITORÍA
  ========================== */

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

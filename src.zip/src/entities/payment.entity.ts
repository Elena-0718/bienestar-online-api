import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';

import { Order } from './order.entity';

/* =========================
   ENUM MÉTODOS DE PAGO
========================== */
export enum PaymentMethod {
  CASH = 'CASH',                 // Contra entrega
  TRANSFER = 'TRANSFER',         // Transferencia bancaria
  CARD = 'CARD',                 // Tarjeta débito/crédito
  PAYPAL = 'PAYPAL',
  MERCADOPAGO = 'MERCADOPAGO',
}

/* =========================
   ENUM ESTADO DEL PAGO
========================== */
export enum PaymentStatus {
  PENDING = 'PENDING',           // Creado, sin confirmar
  CONFIRMED = 'CONFIRMED',       // Pago aprobado
  REJECTED = 'REJECTED',         // Pago rechazado
  CANCELED = 'CANCELED',         // Cancelado
}

@Entity({ name: 'payments' })
@Index(['status'])
@Index(['method'])
export class Payment {
  /* =========================
     IDENTIFICACIÓN
  ========================== */
  @PrimaryGeneratedColumn('uuid')
  uuid: string;

  /* =========================
     MONTO DEL PAGO
  ========================== */
  @Column({
    type: 'decimal',
    precision: 10,
    scale: 2,
    nullable: false,
    comment: 'Monto total pagado',
  })
  total: number;

  /* =========================
     MÉTODO DE PAGO
  ========================== */
  @Column({
    type: 'enum',
    enum: PaymentMethod,
    nullable: false,
  })
  method: PaymentMethod;

  /* =========================
     ESTADO DEL PAGO
  ========================== */
  @Column({
    type: 'enum',
    enum: PaymentStatus,
    default: PaymentStatus.PENDING,
  })
  status: PaymentStatus;

  /* =========================
     DATOS DE TRANSACCIÓN
  ========================== */

  @Column({
    type: 'varchar',
    length: 150,
    nullable: true,
    comment: 'ID de la transacción en la pasarela de pago',
  })
  transactionId?: string;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: true,
    comment: 'Referencia interna del pago',
  })
  reference?: string;

  @Column({
    type: 'timestamp',
    nullable: true,
    comment: 'Fecha en que el pago fue confirmado',
  })
  paidAt?: Date;

  /* =========================
     RELACIÓN CON ORDEN
  ========================== */
  @OneToOne(() => Order, (order) => order.payment, {
    nullable: false,
    onDelete: 'RESTRICT',
  })
  @JoinColumn({ name: 'order_uuid' })
  order: Order;

  /* =========================
     AUDITORÍA
  ========================== */
  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}



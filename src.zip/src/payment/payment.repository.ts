import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Payment, PaymentStatus, PaymentMethod } from 'src/entities/payment.entity';
import { OrderRepository } from 'src/order/order.repository';
import { UpdatePaymentDto } from './dtos/update-payment.dto';

@Injectable()
export class PaymentRepository {
  constructor(
    @InjectRepository(Payment)
    private readonly paymentRepository: Repository<Payment>,
    private readonly orderRepository: OrderRepository,
  ) {}

  async getPaymentByOrderRepository(orderUuid: string) {
    return this.paymentRepository.findOne({
      where: { order: { uuid: orderUuid } },
      relations: ['order', 'order.user'],
    });
  }

  async getAllPaymentsRepository() {
    return this.paymentRepository.find({
      order: { createdAt: 'DESC' },
      relations: ['order', 'order.user'],
    });
  }

  async putConfirmPaymentRepository(payment: Payment) {
    payment.status = PaymentStatus.CONFIRMED;
    await this.orderRepository.putOrderPreparingRepository(payment.order);
    await this.paymentRepository.save(payment);

    return {
      message: 'Pago confirmado correctamente.',
      payment,
    };
  }

  async putUpdatePaymentStatusRepository(
    payment: Payment,
    dto: UpdatePaymentDto,
  ) {
    if (dto.status) {
      payment.status = dto.status;
    }
    await this.paymentRepository.save(payment);
    return payment;
  }

  async deletePaymentRepository(payment: Payment) {
    payment.status = PaymentStatus.REJECTED;
    await this.paymentRepository.save(payment);
    return payment;
  }

  async postRegisterPaymentRepository(data: {
    method: PaymentMethod;
    total: number;
    order_uuid: string;
  }) {
    const payment = this.paymentRepository.create({
      method: data.method,
      total: data.total,
      order: { uuid: data.order_uuid } as any,
    });

    await this.paymentRepository.save(payment);
    return payment;
  }

  async getPaymentByIdRepository(uuid: string) {
    return this.paymentRepository.findOne({
      where: { uuid },
      relations: ['order', 'order.user'],
    });
  }
}

import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreatePaymentDto } from './dtos/create-payment.dto';
import { PaymentRepository } from './payment.repository';
import { OrderRepository } from 'src/order/order.repository';
import { UpdatePaymentDto } from './dtos/update-payment.dto';
import { PaymentStatus } from 'src/entities/payment.entity';

@Injectable()
export class PaymentService {
  constructor(
    private readonly paymentRepository: PaymentRepository,
    private readonly orderRepository: OrderRepository,
  ) {}

  getAllPaymentsService() {
    return this.paymentRepository.getAllPaymentsRepository();
  }

  async putConfirmPaymentService(uuid: string) {
    const payment = await this.paymentRepository.getPaymentByIdRepository(uuid);
    if (!payment) throw new NotFoundException('Pago no encontrado.');
    if (payment.status === PaymentStatus.CONFIRMED) {
      throw new ConflictException('El pago ya fue confirmado.');
    }
    return this.paymentRepository.putConfirmPaymentRepository(payment);
  }

  async putUpdatePaymentStatusService(uuid: string, dto: UpdatePaymentDto) {
    const payment = await this.paymentRepository.getPaymentByIdRepository(uuid);
    if (!payment) throw new NotFoundException('Pago no encontrado.');
    return this.paymentRepository.putUpdatePaymentStatusRepository(payment, dto);
  }

  async deletePaymentService(uuid: string) {
    const payment = await this.paymentRepository.getPaymentByIdRepository(uuid);
    if (!payment) throw new NotFoundException('Pago no encontrado.');
    return this.paymentRepository.deletePaymentRepository(payment);
  }

  async postRegisterPaymentService(req: any, dto: CreatePaymentDto) {
    const userUuid = req.user.user_uuid;
    const order = await this.orderRepository.getOrderByIdRepository(dto.order_uuid);

    if (!order) throw new NotFoundException('La orden no existe.');
    if (order.user.uuid !== userUuid) {
      throw new BadRequestException('La orden no pertenece al usuario.');
    }

    const existingPayment =
      await this.paymentRepository.getPaymentByOrderRepository(dto.order_uuid);

    if (existingPayment) {
      throw new ConflictException('La orden ya tiene un pago.');
    }

    return this.paymentRepository.postRegisterPaymentRepository({
      method: dto.method,
      total: Number(order.total),
      order_uuid: dto.order_uuid,
    });
  }

  async getPaymentByIdService(uuid: string) {
    const payment = await this.paymentRepository.getPaymentByIdRepository(uuid);
    if (!payment) throw new NotFoundException('Pago no encontrado.');
    return payment;
  }
}
 

import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsUUID } from 'class-validator';
import { PaymentMethod } from 'src/entities/payment.entity';

export class CreatePaymentDto {

  @ApiProperty({
    enum: PaymentMethod,
    description: 'Método de pago válido.',
    example: PaymentMethod.CARD,
  })
  @IsEnum(PaymentMethod, {
    message: 'El método de pago no es válido.',
  })
  @IsNotEmpty()
  method: PaymentMethod;

  @ApiProperty({
    description: 'UUID de la orden asociada al pago.',
  })
  @IsUUID()
  @IsNotEmpty()
  order_uuid: string;
}

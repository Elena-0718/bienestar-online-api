import {
  Controller,
  Get,
  Put,
  Delete,
  Param,
  Body,
  HttpCode,
  HttpStatus,
  UseGuards,
  Query,
  ParseUUIDPipe,
  Req,
  Patch,
} from '@nestjs/common';
import { CredentialService } from './credential.service';
import {
  ApiBearerAuth,
  ApiBody,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/Guards/jwt-auth.guard';
import { RolesGuard } from 'src/auth/Guards/roles.guard';
import { RolesDecorator } from 'src/decoratos/roles.decorator';
import { Roles } from 'src/enum/roles.enum';
import { ChangePasswordDto } from './dtos/change-password.dto';
import { ChangeRoleDto } from './dtos/change-role.dto';

@ApiTags('Credenciales de usuarios')
@ApiBearerAuth()
@Controller('credentials')
@UseGuards(JwtAuthGuard, RolesGuard)
export class CredentialController {
  constructor(private readonly credentialService: CredentialService) {}

  /* =========================
     RUTAS ADMIN
  ========================== */

  @Get('all')
@ApiOperation({
  summary: 'Obtener todas las credenciales | ADMIN',
})
@ApiQuery({ name: 'email', required: false })
@HttpCode(HttpStatus.OK)
@RolesDecorator(Roles.ADMIN)
getAllCredentials(@Query('email') email?: string) {
  if (email) {
    return this.credentialService.getCredentialByEmailService(email);
  }
  return this.credentialService.getAllCredentialsService();
}


  @Get(':uuid')
  @ApiOperation({
    summary: 'Obtener credencial por UUID | ADMIN',
  })
  @ApiParam({ name: 'uuid', type: 'string' })
  @HttpCode(HttpStatus.OK)
  @RolesDecorator(Roles.ADMIN)
  getCredentialById(@Param('uuid', ParseUUIDPipe) uuid: string) {
    return this.credentialService.getCredentialByIdService(uuid);
  }

  /* =========================
     RUTAS COMPARTIDAS
  ========================== */


  @Patch('change-password/:uuid')
  @ApiOperation({ summary: 'Cambiar contraseña | PROPIO' })
  @ApiBody({ type: ChangePasswordDto })
  @HttpCode(HttpStatus.OK)
  @RolesDecorator(Roles.ADMIN, Roles.USER, Roles.PROFESSIONAL)
  changePassword(
    @Param('uuid', ParseUUIDPipe) uuid: string,
    @Body() dto: ChangePasswordDto,
    @Req() req,
  ) {
    return this.credentialService.patchChangePasswordService(
      uuid,
      dto,
      req.user,
    );
  }

  @Delete('desactivate/:uuid')
  @ApiOperation({ summary: 'Desactivar cuenta | PROPIO o ADMIN' })
  @HttpCode(HttpStatus.OK)
  @RolesDecorator(Roles.ADMIN, Roles.USER, Roles.PROFESSIONAL)
  deleteCredential(
    @Param('uuid', ParseUUIDPipe) uuid: string,
    @Req() req,
  ) {
    return this.credentialService.deleteCredentialService(uuid, req.user);
  }

  @Put('activate/:uuid')
  @ApiOperation({ summary: 'Activar cuenta | ADMIN' })
  @HttpCode(HttpStatus.OK)
  @RolesDecorator(Roles.ADMIN)
  activateCredential(@Param('uuid', ParseUUIDPipe) uuid: string) {
    return this.credentialService.activateCredentialService(uuid);
  }

  @Put('change-role/:uuid')
  @ApiOperation({ summary: 'Cambiar rol | ADMIN' })
  @ApiBody({ type: ChangeRoleDto })
  @HttpCode(HttpStatus.OK)
  @RolesDecorator(Roles.ADMIN)
  changeRole(
    @Param('uuid', ParseUUIDPipe) uuid: string,
    @Body() dto: ChangeRoleDto,
  ) {
    return this.credentialService.putChangeUserRole(uuid, dto);
  }
}

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
} from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';

import { PlanService } from './plan.service';
import { CreatePlanDto } from './dtos/create-plan.dto';
import { UpdatePlanDto } from './dtos/update-plan.dto';

@ApiTags('Plans')
@Controller('plans')
export class PlanController {
  constructor(private readonly planService: PlanService) {}

  // =========================
  // USER
  // =========================

  @Get('active')
  @ApiOperation({ summary: 'Obtener planes activos' })
  getActivePlans() {
    return this.planService.getActivePlans();
  }

  // =========================
  // ADMIN
  // =========================

  @Get()
  @ApiOperation({ summary: 'Obtener todos los planes' })
  getAllPlans() {
    return this.planService.getAllPlans();
  }

  @Get(':uuid')
  @ApiOperation({ summary: 'Obtener plan por ID' })
  getPlanById(@Param('uuid') uuid: string) {
    return this.planService.getPlanById(uuid);
  }

  @Post()
  @ApiOperation({ summary: 'Crear plan' })
  createPlan(@Body() dto: CreatePlanDto) {
    return this.planService.createPlan(dto);
  }

  @Patch(':uuid')
  @ApiOperation({ summary: 'Actualizar plan' })
  updatePlan(
    @Param('uuid') uuid: string,
    @Body() dto: UpdatePlanDto,
  ) {
    return this.planService.updatePlan(uuid, dto);
  }

  @Delete(':uuid')
  @ApiOperation({ summary: 'Desactivar plan' })
  deletePlan(@Param('uuid') uuid: string) {
    return this.planService.deletePlan(uuid);
  }
}

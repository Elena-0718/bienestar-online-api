import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';

import { UserRepository } from './user.repository';
import { UpdateUserDto } from './dtos/updateUser.dto';
import { User } from '../entities/users.entity';

@Injectable()
export class UserService {
  constructor(
    private readonly userRepository: UserRepository,
  ) {}

  // ===============================
  // ADMIN
  // ===============================

  async getAllUsersService(): Promise<User[]> {
    return this.userRepository.getAllUsersRepository();
  }

  async getUserByIdService(userUuid: string): Promise<User> {
    const user =
      await this.userRepository.getUserByIdRepository(
        userUuid,
      );

    if (!user) {
      throw new NotFoundException('Usuario no encontrado.');
    }

    return user;
  }

  // ===============================
  // PERFIL PROPIO (JWT)
  // ===============================

  async getUserProfileService(req: {
    user: { user_uuid: string };
  }): Promise<User> {
    const userUuid = req.user.user_uuid;

    const user =
      await this.userRepository.getUserProfileRepository(
        userUuid,
      );

    if (!user) {
      throw new NotFoundException('Usuario no encontrado.');
    }

    if (!user.isActive) {
      throw new ConflictException(
        'Este perfil se encuentra desactivado.',
      );
    }

    return user;
  }

  async updateUserProfileService(
    req: { user: { user_uuid: string } },
    updateUserDto: UpdateUserDto,
  ): Promise<{ message: string }> {
    const userUuid = req.user.user_uuid;

    const user =
      await this.userRepository.getUserByIdRepository(
        userUuid,
      );

    if (!user) {
      throw new NotFoundException('Usuario no encontrado.');
    }

    if (!user.isActive) {
      throw new ConflictException(
        'Este usuario se encuentra desactivado.',
      );
    }

    // 🔐 Email y documento NO se actualizan por seguridad
    return this.userRepository.updateUserProfileRepository(
      user,
      updateUserDto,
    );
  }

  // ===============================
  // DESACTIVAR USUARIO
  // ===============================

  async deactivateUserService(
    userUuid: string,
  ): Promise<{ message: string }> {
    const user =
      await this.userRepository.getUserByIdRepository(
        userUuid,
      );

    if (!user) {
      throw new NotFoundException('Usuario no encontrado.');
    }

    return this.userRepository.softDeleteUserRepository(
      user,
    );
  }
}

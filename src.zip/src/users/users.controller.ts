import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Put,
  Req,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiBody,
  ApiOperation,
  ApiParam,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';

import { UpdateUserDto } from './dtos/updateUser.dto';
import { UserService } from './users.service';

import { RolesDecorator } from 'src/decoratos/roles.decorator';
import { Roles } from 'src/enum/roles.enum';
import { JwtAuthGuard } from 'src/auth/Guards/jwt-auth.guard';
import { RolesGuard } from 'src/auth/Guards/roles.guard';

@ApiTags('Usuarios')
@ApiBearerAuth()
@Controller('users')
@UseGuards(JwtAuthGuard, RolesGuard)
export class UserController {
  constructor(
    private readonly userService: UserService,
  ) {}

  /* ===============================
     ADMIN
  =============================== */

  @Get('all')
  @ApiOperation({
    summary: 'Obtener todos los usuarios | ADMIN',
    description:
      'Retorna la lista completa de usuarios (activos e inactivos).',
  })
  @ApiResponse({
    status: 200,
    description: 'Listado de usuarios obtenido correctamente.',
  })
  @HttpCode(HttpStatus.OK)
  @RolesDecorator(Roles.ADMIN)
  getAllUsers() {
    return this.userService.getAllUsersService();
  }

  @Get('find/:uuid')
  @ApiOperation({
    summary: 'Obtener usuario por UUID | ADMIN',
    description:
      'Retorna el perfil de un usuario específico mediante su UUID.',
  })
  @ApiParam({
    name: 'uuid',
    description: 'UUID del usuario',
    example: 'c31a34b7-8b9a-4e71-a29a-8c26f675a1c8',
  })
  @ApiResponse({
    status: 200,
    description: 'Usuario obtenido correctamente.',
  })
  @HttpCode(HttpStatus.OK)
  @RolesDecorator(Roles.ADMIN)
  getUserById(
    @Param('uuid', ParseUUIDPipe) uuid: string,
  ) {
    return this.userService.getUserByIdService(uuid);
  }

  /* ===============================
     PERFIL PROPIO
  =============================== */

  @Get('my-profile')
  @ApiOperation({
    summary: 'Ver mi perfil | USER / PROFESSIONAL / ADMIN',
    description:
      'Retorna la información del usuario autenticado.',
  })
  @ApiResponse({
    status: 200,
    description: 'Perfil obtenido correctamente.',
  })
  @HttpCode(HttpStatus.OK)
  @RolesDecorator(
    Roles.USER,
    Roles.PROFESSIONAL,
    Roles.ADMIN,
  )
  getMyProfile(@Req() req) {
    return this.userService.getUserProfileService(req);
  }

  @Put('update-my-profile')
  @ApiOperation({
    summary: 'Actualizar mi perfil | USER / PROFESSIONAL / ADMIN',
    description:
      'Permite actualizar los datos básicos del usuario autenticado.',
  })
  @ApiBody({
    type: UpdateUserDto,
    description:
      'Datos permitidos para la actualización del perfil.',
  })
  @ApiResponse({
    status: 200,
    description: 'Perfil actualizado correctamente.',
  })
  @HttpCode(HttpStatus.OK)
  @RolesDecorator(
    Roles.USER,
    Roles.PROFESSIONAL,
    Roles.ADMIN,
  )
  updateMyProfile(
    @Req() req,
    @Body() updateUserDto: UpdateUserDto,
  ) {
    return this.userService.updateUserProfileService(
      req,
      updateUserDto,
    );
  }
}


import { ApiProperty } from '@nestjs/swagger';
import {
  IsDateString,
  IsEmail,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
  Min,
  Max,
} from 'class-validator';
import { Type } from 'class-transformer';

import { Objective } from 'src/enum/objective.enum';
import { Sex } from 'src/enum/sex.enum';

export class CreateUserDto {

  /* =========================
     DATOS PERSONALES
  ========================== */

  @ApiProperty({
    description: 'Nombre completo del usuario',
    example: 'Ana Milena Reyes Castro',
  })
  @IsNotEmpty({ message: 'El nombre completo es obligatorio.' })
  @IsString()
  @Matches(/^[\p{L}\s]+$/u, {
    message: 'El nombre solo debe contener letras y espacios.',
  })
  @MaxLength(150)
  fullName: string;

  @ApiProperty({
    description: 'Documento de identidad (solo números)',
    example: '1032456789',
  })
  @IsNotEmpty({ message: 'El documento es obligatorio.' })
  @IsString()
  @Matches(/^\d+$/, {
    message: 'El documento solo debe contener números.',
  })
  @MaxLength(20)
  document: string;

  @ApiProperty({
    description: 'Fecha de nacimiento (YYYY-MM-DD)',
    example: '1998-06-15',
  })
  @IsNotEmpty({ message: 'La fecha de nacimiento es obligatoria.' })
  @IsDateString({}, {
    message: 'La fecha debe tener formato válido (YYYY-MM-DD).',
  })
  birthDate: string;

  @ApiProperty({
    description: 'Sexo del usuario',
    enum: Sex,
    example: Sex.FEMALE,
  })
  @IsNotEmpty({ message: 'El sexo es obligatorio.' })
  @IsEnum(Sex, {
    message: 'El sexo debe ser MALE, FEMALE u OTHER.',
  })
  sex: Sex;

  @ApiProperty({
    description: 'Número de teléfono colombiano',
    example: '3146780918',
  })
  @IsNotEmpty({ message: 'El teléfono es obligatorio.' })
  @IsString()
  @Matches(/^(?:\+57)?3\d{9}$/, {
    message: 'Debe ser un número colombiano válido.',
  })
  phone: string;

  @ApiProperty({
    description: 'Correo electrónico',
    example: 'usuario@correo.com',
  })
  @IsNotEmpty({ message: 'El correo es obligatorio.' })
  @IsEmail({}, { message: 'Correo electrónico no válido.' })
  @MaxLength(150)
  email: string;

  /* =========================
     PERFIL DE BIENESTAR
  ========================== */

  @ApiProperty({
    description: 'Objetivo del usuario',
    enum: Objective,
    example: Objective.GAIN_MUSCLE,
  })
  @IsNotEmpty({ message: 'El objetivo es obligatorio.' })
  @IsEnum(Objective, {
    message: 'El objetivo no es válido.',
  })
  objective: Objective;

  @ApiProperty({
    description: 'Peso en kilogramos',
    example: 68.5,
    required: false,
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber({}, { message: 'El peso debe ser un número.' })
  @Min(30, { message: 'El peso mínimo permitido es 30 kg.' })
  @Max(300, { message: 'El peso máximo permitido es 300 kg.' })
  weight?: number;

  @ApiProperty({
    description: 'Altura en metros',
    example: 1.65,
    required: false,
  })
  @IsOptional()
  @Type(() => Number)
  @IsNumber({}, { message: 'La altura debe ser un número.' })
  @Min(1, { message: 'La altura mínima permitida es 1 metro.' })
  @Max(3, { message: 'La altura máxima permitida es 3 metros.' })
  height?: number;

  @ApiProperty({
    description: 'Observaciones médicas o personales',
    example: 'Intolerancia a la lactosa',
    required: false,
  })
  @IsOptional()
  @IsString()
  @MaxLength(500)
  observations?: string;

  @ApiProperty({
    description: 'URL de la foto de perfil',
    example: 'https://cdn.bienestaronline.com/photos/user123.jpg',
    required: false,
  })
  @IsOptional()
  @IsString()
  photoUrl?: string;
}


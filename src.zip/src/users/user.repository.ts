import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { User } from '../entities/users.entity';
import { UpdateUserDto } from './dtos/updateUser.dto';



@Injectable()
export class UserRepository {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  // ===============================
  // BÚSQUEDAS
  // ===============================

  async getUserByEmailRepository(email: string): Promise<User | null> {
    return this.userRepository.findOne({
      where: { email },
      relations: ['credential'],
    });
  }

  async getUserByDocumentRepository(document: string): Promise<User | null> {
    return this.userRepository.findOne({
      where: { document },
      relations: ['credential'],
    });
  }

  async getUserByIdRepository(uuid: string): Promise<User | null> {
    return this.userRepository.findOne({
      where: { uuid },
      relations: ['credential'],
    });
  }

  async getAllUsersRepository(): Promise<User[]> {
    return this.userRepository.find({
      order: { fullName: 'ASC' },
      relations: ['credential'],
    });
  }

  // ===============================
  // CREACIÓN
  // ===============================

  async createUserRepository(newUser: Partial<User>): Promise<User> {
    const user = this.userRepository.create(newUser);
    return this.userRepository.save(user);
  }

  // ===============================
  // PERFIL DE USUARIO
  // ===============================

  /**
   * Obtiene el perfil del usuario autenticado
   * (misma consulta que getUserById, se mantiene por semántica)
   */
  async getUserProfileRepository(uuid: string): Promise<User | null> {
    return this.userRepository.findOne({
      where: { uuid },
      relations: ['credential'],
    });
  }

  async updateUserProfileRepository(
    userExists: User,
    updateUserDto: UpdateUserDto,
  ): Promise<{ message: string }> {
    Object.assign(userExists, updateUserDto);

    await this.userRepository.save(userExists);

    return {
      message: 'Perfil de usuario actualizado correctamente.',
    };
  }

  // ===============================
  // ELIMINACIÓN LÓGICA
  // ===============================

  async softDeleteUserRepository(
    user: User,
  ): Promise<{ message: string }> {
    user.isActive = false;

    await this.userRepository.save(user);

    return {
      message: 'Usuario desactivado correctamente.',
    };
  }
}


import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { CredentialModule } from 'src/credential/credential.module';
import { UserModule } from 'src/users/users.module';

@Module({
  imports: [
    CredentialModule,
    UserModule,

    JwtModule.register({
      global: true, // 👈 IMPORTANTE
      secret: process.env.JWT_SECRET || 'default_jwt_secret',
      signOptions: {
        expiresIn: '1d',
      },
    }),
  ],
  controllers: [AuthController],
  providers: [AuthService],
})
export class AuthModule {}


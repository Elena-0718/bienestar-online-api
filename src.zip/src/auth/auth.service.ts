import {
  ConflictException,
  Injectable,
  UnauthorizedException,
  NotFoundException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';

import { CredentialRepository } from 'src/credential/credential.repository';
import { LoginDto } from 'src/credential/dtos/login.dto';
import { SignUpDto } from 'src/credential/dtos/sing-up.dto';
import { UserRepository } from 'src/users/user.repository';

@Injectable()
export class AuthService {
  constructor(
    private readonly credentialRepository: CredentialRepository,
    private readonly userRepository: UserRepository,
    private readonly jwtService: JwtService,
  ) {}

  /* ===============================
     REGISTRO DE USUARIO
  =============================== */
  async signUpService(signUpDto: SignUpDto) {
    const { createCredentialDto, createUserDto } = signUpDto;

    // 1️⃣ Verificar si ya existe la credencial
    const credentialExists =
      await this.credentialRepository.getCredentialByEmailRepository(
        createCredentialDto.email,
      );

    if (credentialExists) {
      throw new ConflictException(
        'Este correo ya se encuentra registrado.',
      );
    }

    // 2️⃣ Hashear contraseña
    const hashedPassword = await bcrypt.hash(
      createCredentialDto.password,
      10,
    );

    // 3️⃣ Crear credencial
    const newCredential =
      await this.credentialRepository.postCreateCredentialRepository({
        email: createCredentialDto.email,
        password: hashedPassword,
      });

    // 4️⃣ Verificar si ya existe usuario con ese email
    const userExists =
      await this.userRepository.getUserByEmailRepository(
        createUserDto.email,
      );

    if (userExists) {
      throw new ConflictException('El usuario ya existe.');
    }

    // 5️⃣ Crear usuario
    const newUser = await this.userRepository.createUserRepository({
      fullName: createUserDto.fullName,
      document: createUserDto.document,
      birthDate: new Date(createUserDto.birthDate),
      sex: createUserDto.sex,
      phone: createUserDto.phone,
      email: createUserDto.email,
      objective: createUserDto.objective,
      weight: createUserDto.weight,
      height: createUserDto.height,
      observations: createUserDto.observations,
      photoUrl: createUserDto.photoUrl,
      credential: newCredential,
    });

    // 6️⃣ Limpiar respuesta
    const { password, ...credentialWithoutPassword } = newCredential;
    const userWithoutCredential = { ...newUser };
    delete (userWithoutCredential as any).credential;

    return {
      message: 'Usuario registrado exitosamente.',
      credential: credentialWithoutPassword,
      profile: userWithoutCredential,
    };
  }

  /* ===============================
     LOGIN
  =============================== */
  async signInService(loginDto: LoginDto) {
    const { email, password } = loginDto;

    // 1️⃣ Buscar credencial CON relación user
    const credential =
      await this.credentialRepository.getCredentialByEmailRepository(email);

    if (!credential) {
      throw new UnauthorizedException('Credenciales incorrectas.');
    }

    // 2️⃣ Verificar cuenta activa
    if (!credential.isActive) {
      throw new UnauthorizedException(
        'La cuenta se encuentra desactivada.',
      );
    }

    // 3️⃣ Verificar relación con usuario
    if (!credential.user || !credential.user.isActive) {
      throw new UnauthorizedException('Usuario inválido.');
    }

    // 4️⃣ Verificar contraseña
    const isPasswordValid = await bcrypt.compare(
      password,
      credential.password,
    );

    if (!isPasswordValid) {
      throw new UnauthorizedException('Credenciales incorrectas.');
    }

    // 5️⃣ Crear payload del token
    const payload = {
      credential_uuid: credential.uuid,
      user_uuid: credential.user.uuid,
      email: credential.email,
      role: credential.role,
    };

    // 6️⃣ Firmar token
    const accessToken = this.jwtService.sign(payload);

    return {
      message: 'Inicio de sesión exitoso.',
      access_token: accessToken,
      expires_in: process.env.JWT_EXPIRES_IN ?? '1h',
    };
  }
}

import { Module } from '@nestjs/common';

import { CartDetailService } from './cartDetail.service';
import { CartDetailController } from './cartDetail.controller';


@Module({
  controllers: [CartDetailController],
  providers: [CartDetailService]
})
export class CartDetailModule {}

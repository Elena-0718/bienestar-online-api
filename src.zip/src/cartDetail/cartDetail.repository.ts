import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { CartRepository } from 'src/cart/cart.repository';
import { AddProductDto } from './dtos/add-product.dto';
import { CartDetail } from 'src/entities/cartDetail.entity';

@Injectable()
export class CartDetailRepository {
  constructor(
    @InjectRepository(CartDetail)
    private readonly cartDetailRepository: Repository<CartDetail>,
    private readonly cartRepository: CartRepository,
  ) {}

  async postAddProductRepository(
    cartUuid: string,
    addProductDto: AddProductDto,
    unitPrice: number,
  ) {
    const newDetail = this.cartDetailRepository.create({
      cart: { uuid: cartUuid } as any,
      product: { uuid: addProductDto.product_uuid } as any,
      quantity: addProductDto.quantity,
      unitPrice,
      subtotal: addProductDto.quantity * unitPrice,
    });

    const savedDetail = await this.cartDetailRepository.save(newDetail);

    await this.cartRepository.updateCartSubtotal(cartUuid);

    return {
      message: 'Producto añadido al carrito correctamente.',
      detail: savedDetail,
    };
  }

  async putUpdateProductQuantityRepository(
    detailUuid: string,
    quantity: number,
  ) {
    const detail = await this.cartDetailRepository.findOne({
      where: { uuid: detailUuid },
      relations: ['cart'],
    });

    if (!detail) return null;

    detail.quantity = quantity;
    detail.subtotal = quantity * Number(detail.unitPrice);

    const saved = await this.cartDetailRepository.save(detail);
    await this.cartRepository.updateCartSubtotal(detail.cart.uuid);

    return {
      message: `Cantidad del producto actualizada a ${quantity}.`,
      detail: saved,
    };
  }

  async deleteProductCartRepository(
    detailUuid: string,
    cartUuid: string,
  ) {
    const detail = await this.cartDetailRepository.findOne({
      where: {
        uuid: detailUuid,
        cart: { uuid: cartUuid },
      },
      relations: ['cart'],
    });

    if (!detail) return null;

    await this.cartDetailRepository.remove(detail);
    await this.cartRepository.updateCartSubtotal(cartUuid);

    return {
      message: 'Producto eliminado del carrito correctamente.',
    };
  }
}

import { DataSource } from 'typeorm';
import { NutritionPlan } from '../../entities/nutrition-plan.entity';
import { Subscription } from '../../entities/subscription.entity';
import { Professional } from '../../entities/professional.entity';
import { User } from '../../entities/users.entity';
import { SubscriptionStatus } from '../../enum/subscription-status.enum';

import {
  nataliaWeeklyPlan,
  lauraWeeklyPlan,
} from '../data/nutrition-plans.data';


export async function nutritionPlanSeed(
  dataSource: DataSource,
): Promise<void> {
  const nutritionRepo = dataSource.getRepository(NutritionPlan);
  const subscriptionRepo = dataSource.getRepository(Subscription);
  const professionalRepo = dataSource.getRepository(Professional);
  const userRepo = dataSource.getRepository(User);

  const professional = await professionalRepo.findOne({
    where: { isActive: true },
  });

  if (!professional) throw new Error('No hay profesional activo');

  const users = [
    {
      email: 'natalia.rios@gmail.com',
      weeklyPlan: nataliaWeeklyPlan,
      objective: 'Pérdida de peso',
    },
    {
      email: 'laura.gomez@gmail.com',
      weeklyPlan: lauraWeeklyPlan,
      objective: 'Hábitos saludables',
    },
  ];

  for (const u of users) {
    const user = await userRepo.findOne({ where: { email: u.email } });
    if (!user) continue;

    const subscription = await subscriptionRepo.findOne({
      where: {
        user: { uuid: user.uuid },
        status: SubscriptionStatus.ACTIVE,
      },
      relations: ['user'],
    });

    if (!subscription) continue;

    const exists = await nutritionRepo.findOne({
      where: { subscription: { uuid: subscription.uuid } },
    });

    if (exists) continue;

    await nutritionRepo.save({
      subscription,
      professional,
      weeklyPlan: u.weeklyPlan,
      objective: u.objective,
      isActive: true,
    });
  }
}

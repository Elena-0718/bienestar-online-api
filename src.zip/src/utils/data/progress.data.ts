import { ProgressSeedData } from '../interfaces/progress-seed.interface';

export const progressData: ProgressSeedData[] = [
  // =======================
  // ANDRÉS – FITNESS PLAN
  // =======================
  {
    userEmail: 'andres.morales@gmail.com',
    recordDate: '2025-01-10',
    weightKg: 70,
    bodyFatPercentage: 18,
    muscleMassKg: 32,
    waistCm: 82,
    chestCm: 98,
    energyLevel: 'ALTA',
    adherenceLevel: 'EXCELENTE',
    professionalNotes: 'Buen inicio del plan de fuerza.',
    userNotes: 'Me sentí con buena energía.',
  },
  {
    userEmail: 'andres.morales@gmail.com',
    recordDate: '2025-01-17',
    weightKg: 71,
    bodyFatPercentage: 17.5,
    muscleMassKg: 33,
    waistCm: 81,
    chestCm: 100,
    energyLevel: 'ALTA',
    adherenceLevel: 'EXCELENTE',
    professionalNotes: 'Incremento de masa muscular.',
  },

  // =======================
  // LAURA – BIENESTAR
  // =======================
  {
    userEmail: 'laura.gomez@gmail.com',
    recordDate: '2025-01-12',
    weightKg: 65,
    bodyFatPercentage: 26,
    waistCm: 76,
    hipCm: 98,
    energyLevel: 'MEDIA',
    adherenceLevel: 'BUENA',
    professionalNotes: 'Buen equilibrio entre nutrición y ejercicio.',
    userNotes: 'Me siento más activa.',
  },
  {
    userEmail: 'laura.gomez@gmail.com',
    recordDate: '2025-01-19',
    weightKg: 64.5,
    bodyFatPercentage: 25.5,
    waistCm: 75,
    hipCm: 97,
    energyLevel: 'ALTA',
    adherenceLevel: 'MUY_BUENA',
  },

  // =======================
  // NATALIA – NUTRICIONAL
  // =======================
  {
    userEmail: 'natalia.rios@gmail.com',
    recordDate: '2025-01-11',
    weightKg: 76,
    bodyFatPercentage: 34,
    waistCm: 90,
    energyLevel: 'MEDIA',
    adherenceLevel: 'BUENA',
    professionalNotes: 'Buena adherencia al plan nutricional.',
    userNotes: 'Me cuesta dejar el azúcar.',
  },
  {
    userEmail: 'natalia.rios@gmail.com',
    recordDate: '2025-01-18',
    weightKg: 75,
    bodyFatPercentage: 33.2,
    waistCm: 88,
    energyLevel: 'MEJORANDO',
    adherenceLevel: 'MUY_BUENA',
    professionalNotes: 'Reducción de peso progresiva.',
  },
];

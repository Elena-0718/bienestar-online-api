export const nataliaWeeklyPlan = {
  monday: {
    breakfast: [
      {
        name: 'Huevos revueltos con espinaca',
        calories: 250,
        portions: '1 plato',
      },
    ],
    lunch: [
      {
        name: 'Pechuga de pollo a la plancha',
        calories: 420,
        portions: '1 plato',
      },
    ],
    dinner: [
      {
        name: 'Sopa de verduras',
        calories: 180,
        portions: '1 tazón',
      },
    ],
    snacks: [
      {
        name: 'Yogur sin lactosa',
        calories: 90,
        portions: '1 vaso',
      },
    ],
  },
  // tuesday, wednesday...
};

export const lauraWeeklyPlan = {
  monday: {
    breakfast: [
      {
        name: 'Pan integral con aguacate',
        calories: 300,
        portions: '2 tostadas',
      },
    ],
    lunch: [
      {
        name: 'Bowl balanceado',
        calories: 480,
        portions: '1 bowl',
      },
    ],
    dinner: [
      {
        name: 'Wrap de vegetales',
        calories: 350,
        portions: '1 wrap',
      },
    ],
  },
  // tuesday, wednesday...
};

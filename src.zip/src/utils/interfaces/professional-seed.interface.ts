import { ProfessionalType } from '../../entities/professional.entity';

export interface ProfessionalSeedData {
  userEmail: string;
  type: ProfessionalType;
  professionalTitle: string;
  licenseNumber?: string;
  yearsOfExperience: number;
  bio?: string;
}


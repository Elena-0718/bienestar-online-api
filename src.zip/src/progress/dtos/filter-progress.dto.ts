import { IsDateString, IsOptional } from 'class-validator';

export class FilterProgressDto {
  @IsOptional()
  @IsDateString()
  from?: string;

  @IsOptional()
  @IsDateString()
  to?: string;
}

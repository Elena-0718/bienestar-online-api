import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ProgressService } from './progress.service';

import { JwtAuthGuard } from 'src/auth/Guards/jwt-auth.guard';
import { RolesGuard } from 'src/auth/Guards/roles.guard';
import { RolesDecorator } from 'src/decoratos/roles.decorator';
import { Roles } from 'src/enum/roles.enum';

import { CreateProgressDto } from './dtos/create-progress.dto';
import { UpdateProgressDto } from './dtos/update-progress.dto';

@Controller('progress')
@UseGuards(JwtAuthGuard, RolesGuard)
export class ProgressController {
  constructor(
    private readonly progressService: ProgressService,
  ) {}

  /* =========================
     CREATE
  ========================== */
  @Post(':userUuid')
  @RolesDecorator(Roles.ADMIN, Roles.PROFESSIONAL)
  async create(
    @Param('userUuid') userUuid: string,
    @Req() req: any,
    @Body() dto: CreateProgressDto,
  ) {
    const professionalUuid = req.user.uuid;
    return this.progressService.create(
      userUuid,
      professionalUuid,
      dto,
    );
  }

  /* =========================
     FIND ONE
  ========================== */
  @Get(':uuid')
  @RolesDecorator(Roles.ADMIN, Roles.PROFESSIONAL, Roles.USER)
  async findByUuid(
    @Param('uuid') uuid: string,
  ) {
    return this.progressService.findByUuid(uuid);
  }

  /* =========================
     HISTORY BY USER
     ?from=2024-01-01&to=2024-01-31
  ========================== */
  @Get('user/:userUuid')
  @RolesDecorator(Roles.ADMIN, Roles.PROFESSIONAL, Roles.USER)
  async findByUser(
    @Param('userUuid') userUuid: string,
    @Query('from') from?: string,
    @Query('to') to?: string,
  ) {
    return this.progressService.findByUser(
      userUuid,
      from,
      to,
    );
  }

  /* =========================
     UPDATE
  ========================== */
  @Patch(':uuid')
  @RolesDecorator(Roles.ADMIN, Roles.PROFESSIONAL)
  async update(
    @Param('uuid') uuid: string,
    @Body() dto: UpdateProgressDto,
  ) {
    return this.progressService.update(uuid, dto);
  }

  /* =========================
     DELETE (SOFT)
  ========================== */
  @Delete(':uuid')
  @RolesDecorator(Roles.ADMIN, Roles.PROFESSIONAL)
  async delete(
    @Param('uuid') uuid: string,
  ) {
    return this.progressService.delete(uuid);
  }
}

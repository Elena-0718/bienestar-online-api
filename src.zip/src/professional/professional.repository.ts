import { Injectable } from '@nestjs/common';
import { Professional } from 'src/entities/professional.entity';
import { DataSource, Repository } from 'typeorm';


@Injectable()
export class ProfessionalRepository extends Repository<Professional> {
  constructor(private readonly dataSource: DataSource) {
    super(Professional, dataSource.createEntityManager());
  }
}

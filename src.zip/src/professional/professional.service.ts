import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { ProfessionalRepository } from './professional.repository';

import { User } from 'src/entities/users.entity';
import { CreateProfessionalDto } from './dtos/create-professional.dto';
import { UpdateProfessionalDto } from './dtos/update-professional.dto';
import { ApproveProfessionalDto } from './dtos/approve-professional.dto';

@Injectable()
export class ProfessionalService {
  constructor(
    private readonly professionalRepo: ProfessionalRepository,
  ) {}

  /* =========================
     CREAR PERFIL PROFESIONAL
  ========================== */
  async create(user: User, dto: CreateProfessionalDto) {
    const existing = await this.professionalRepo.findOne({
      where: { user: { uuid: user.uuid } },
    });

    if (existing) {
      throw new BadRequestException(
        'El usuario ya tiene un perfil profesional',
      );
    }

    const professional = this.professionalRepo.create({
      user,
      ...dto,
      isApproved: false,
      isActive: true,
    });

    return this.professionalRepo.save(professional);
  }

  /* =========================
     LISTAR TODOS
  ========================== */
  async findAll() {
    return this.professionalRepo.find({
      relations: ['user'],
    });
  }

  /* =========================
     OBTENER UNO
  ========================== */
  async findOne(uuid: string) {
    const professional = await this.professionalRepo.findOne({
      where: { uuid },
      relations: ['user'],
    });

    if (!professional) {
      throw new NotFoundException('Profesional no encontrado');
    }

    return professional;
  }

  /* =========================
     ACTUALIZAR
  ========================== */
  async update(uuid: string, dto: UpdateProfessionalDto) {
    const professional = await this.findOne(uuid);

    Object.assign(professional, dto);
    return this.professionalRepo.save(professional);
  }

  /* =========================
     APROBAR (ADMIN)
  ========================== */
  async approve(uuid: string, dto: ApproveProfessionalDto) {
    const professional = await this.findOne(uuid);

    professional.isApproved = dto.isApproved;
    return this.professionalRepo.save(professional);
  }

  /* =========================
     DESACTIVAR
  ========================== */
  async deactivate(uuid: string) {
    const professional = await this.findOne(uuid);

    professional.isActive = false;
    return this.professionalRepo.save(professional);
  }

  /* =========================
     ELIMINAR (RARO, PERO EXISTE)
  ========================== */
  async remove(uuid: string) {
    const professional = await this.findOne(uuid);
    await this.professionalRepo.remove(professional);

    return { message: 'Perfil profesional eliminado correctamente' };
  }
}

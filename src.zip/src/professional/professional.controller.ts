import {
  Controller,
  Post,
  Body,
  Get,
  Param,
  Patch,
  Delete,
} from '@nestjs/common';
import { ProfessionalService } from './professional.service';
import { User } from 'src/entities/users.entity';
import { CreateProfessionalDto } from './dtos/create-professional.dto';
import { UpdateProfessionalDto } from './dtos/update-professional.dto';
import { ApproveProfessionalDto } from './dtos/approve-professional.dto';

/*
  ⚠️ NOTA:
  Aquí asumo que ya tienes un decorador tipo @CurrentUser()
  Si no, luego lo conectamos.
*/

@Controller('professionals')
export class ProfessionalController {
  constructor(private readonly professionalService: ProfessionalService) {}

  /* =========================
     CREAR PERFIL
  ========================== */
  @Post()
  create(
    @Body() dto: CreateProfessionalDto,
    @Body('user') user: User, // temporal si no tienes @CurrentUser
  ) {
    return this.professionalService.create(user, dto);
  }

  /* =========================
     LISTAR TODOS
  ========================== */
  @Get()
  findAll() {
    return this.professionalService.findAll();
  }

  /* =========================
     OBTENER UNO
  ========================== */
  @Get(':uuid')
  findOne(@Param('uuid') uuid: string) {
    return this.professionalService.findOne(uuid);
  }

  /* =========================
     ACTUALIZAR
  ========================== */
  @Patch(':uuid')
  update(
    @Param('uuid') uuid: string,
    @Body() dto: UpdateProfessionalDto,
  ) {
    return this.professionalService.update(uuid, dto);
  }

  /* =========================
     APROBAR (ADMIN)
  ========================== */
  @Patch(':uuid/approve')
  approve(
    @Param('uuid') uuid: string,
    @Body() dto: ApproveProfessionalDto,
  ) {
    return this.professionalService.approve(uuid, dto);
  }

  /* =========================
     DESACTIVAR
  ========================== */
  @Patch(':uuid/deactivate')
  deactivate(@Param('uuid') uuid: string) {
    return this.professionalService.deactivate(uuid);
  }

  /* =========================
     ELIMINAR
  ========================== */
  @Delete(':uuid')
  remove(@Param('uuid') uuid: string) {
    return this.professionalService.remove(uuid);
  }
}

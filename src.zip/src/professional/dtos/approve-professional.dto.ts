import { IsBoolean } from 'class-validator';

export class ApproveProfessionalDto {
  @IsBoolean()
  isApproved: boolean;
}

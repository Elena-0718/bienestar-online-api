import {
  Controller,
  Post,
  Get,
  Body,
  Param,
  UseGuards,
  Request,
  Req,
} from '@nestjs/common';

import { ConsultationService } from './consultation.service';
import { JwtAuthGuard } from 'src/auth/Guards/jwt-auth.guard';
import { CreateConsultationDto } from './dtos/create-consultation.dto';

@Controller('consultations')
@UseGuards(JwtAuthGuard)
export class ConsultationController {
  constructor(
    private readonly service: ConsultationService,
  ) {}

  @Post()
  create(
    @Req() req,
    @Body() dto: CreateConsultationDto,
  ) {
    return this.service.create(req.user.uuid, dto);
  }

  @Get('me')
  getMine(@Req() req) {
    return this.service.getMyConsultations(req.user.uuid);
  }

  @Get('professional/:uuid')
  getByProfessional(@Param('uuid') uuid: string) {
    return this.service.getProfessionalConsultations(uuid);
  }

  @Get(':uuid')
  getOne(@Param('uuid') uuid: string) {
    return this.service.findByUuid(uuid);
  }
}

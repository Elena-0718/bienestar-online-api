import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { Consultation } from '../entities/consultation.entity';




@Injectable()
export class ConsultationRepository {
  constructor(
    @InjectRepository(Consultation)
    private readonly db: Repository<Consultation>,
  ) {}

  async create(data: Partial<Consultation>) {
    const entity = this.db.create(data);
    return this.db.save(entity);
  }

  async findByUuid(uuid: string) {
    return this.db.findOne({
      where: { uuid },
      relations: ['user', 'professional', 'subscription'],
    });
  }

  async findByUser(userUuid: string) {
    return this.db.find({
      where: { user: { uuid: userUuid } },
      order: { scheduledAt: 'DESC' },
    });
  }

  async findByProfessional(professionalUuid: string) {
    return this.db.find({
      where: { professional: { uuid: professionalUuid } },
      order: { scheduledAt: 'DESC' },
    });
  }

  async save(consultation: Consultation) {
    return this.db.save(consultation);
  }
}

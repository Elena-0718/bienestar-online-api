import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';

import { ConsultationRepository } from './consultation.repository';

import { SubscriptionService } from '../subscription/subscription.service';

import { Roles } from '../enum/roles.enum';
import { ConsultationStatus, ConsultationType } from 'src/entities/consultation.entity';
import { UserService } from 'src/users/users.service';
import { CreateConsultationDto } from './dtos/create-consultation.dto';
import { UpdateConsultationStatusDto } from './dtos/update-consultation-status.dto';


@Injectable()
export class ConsultationService {
  constructor(
    private readonly repo: ConsultationRepository,
    private readonly subscriptionService: SubscriptionService,
  ) {}

  /* =========================
     CREATE
  ========================== */
  async create(
    userUuid: string,
    dto: CreateConsultationDto,
  ) {
    const subscription =
      await this.subscriptionService.findActiveByUser(userUuid);

    const scheduledAt = new Date(dto.scheduledAt);
    if (scheduledAt < new Date()) {
      throw new BadRequestException(
        'No se puede agendar una consulta en el pasado',
      );
    }

    return this.repo.create({
      user: { uuid: userUuid } as any,
      professional: { uuid: dto.professionalUuid } as any,
      subscription,
      type: dto.type,
      scheduledAt,
      status: ConsultationStatus.SCHEDULED,
    });
  }

  /* =========================
     USER CONSULTATIONS
  ========================== */
  getMyConsultations(userUuid: string) {
    return this.repo.findByUser(userUuid);
  }

  /* =========================
     PROFESSIONAL CONSULTATIONS
  ========================== */
  getProfessionalConsultations(professionalUuid: string) {
    return this.repo.findByProfessional(professionalUuid);
  }

  /* =========================
     FIND ONE
  ========================== */
  async findByUuid(uuid: string) {
    const consultation = await this.repo.findByUuid(uuid);
    if (!consultation) {
      throw new NotFoundException('Consulta no encontrada');
    }
    return consultation;
  }

  /* =========================
     UPDATE STATUS
  ========================== */
  async updateStatus(
    uuid: string,
    dto: UpdateConsultationStatusDto,
  ) {
    const consultation = await this.findByUuid(uuid);

    consultation.status = dto.status;
    consultation.professionalNotes = dto.professionalNotes;

    if (dto.status === ConsultationStatus.COMPLETED) {
      consultation.completedAt = new Date();
    }

    if (dto.status === ConsultationStatus.CANCELED) {
      consultation.canceledAt = new Date();
    }

    return this.repo.save(consultation);
  }
}

import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Subscription } from 'src/entities/subscription.entity';
import { User } from 'src/entities/users.entity';
import { Plan } from 'src/entities/plan.entity';
import { UpdateSubscriptionStatusDto } from './dtos/updateSubscription.dto';
import { UpdateSubscriptionDatesDto } from './dtos/UpdateSubscriptionDates.dto';
import { BillingCycle } from 'src/enum/billingcycle.enum';
import { SubscriptionStatus } from 'src/enum/subscription-status.enum';


@Injectable()
export class SubscriptionRepository {
  constructor(
    @InjectRepository(Subscription)
    private readonly subscriptionRepo: Repository<Subscription>,

    @InjectRepository(User)
    private readonly userRepo: Repository<User>,

    @InjectRepository(Plan)
    private readonly planRepo: Repository<Plan>,
  ) {}

  // =========================
  // CREATE
  // =========================

  async createSubscription(data: {
    user: User;
    plan: Plan;
    billingCycle: BillingCycle
    startDate: Date;
    endDate?: Date;
  }) {
    const subscription = this.subscriptionRepo.create({
      user: data.user,
      plan: data.plan,
      billingCycle: data.billingCycle,
      startDate: data.startDate,
      endDate: data.endDate ?? null,
      status: SubscriptionStatus.ACTIVE,
    });

    return await this.subscriptionRepo.save(subscription);
  }

  // =========================
  // READ
  // =========================

  getAllSubscriptions() {
    return this.subscriptionRepo.find({
      relations: ['user', 'plan'],
      order: { createdAt: 'DESC' },
    });
  }

  getSubscriptionById(uuid: string) {
    return this.subscriptionRepo.findOne({
      where: { uuid },
      relations: ['user', 'plan'],
    });
  }

  getActiveSubscriptionByUser(userUuid: string) {
    return this.subscriptionRepo.findOne({
      where: {
        user: { uuid: userUuid },
        status: SubscriptionStatus.ACTIVE,
      },
      relations: ['user', 'plan'],
    });
  }

  // =========================
  // UPDATE
  // =========================

  async updateSubscriptionStatus(
    subscription: Subscription,
    dto: UpdateSubscriptionStatusDto,
  ) {
    subscription.status = dto.status;
    return await this.subscriptionRepo.save(subscription);
  }

  async updateSubscriptionDates(
    subscription: Subscription,
    dto: UpdateSubscriptionDatesDto,
  ) {
    if (dto.endDate) {
      subscription.endDate = new Date(dto.endDate);
    }
    return await this.subscriptionRepo.save(subscription);
  }
}

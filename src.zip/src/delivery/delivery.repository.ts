import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Delivery, DeliveryStatus } from 'src/entities/delivery.entity';
import { Order } from 'src/entities/order.entity';

@Injectable()
export class DeliveryRepository {
  constructor(
    @InjectRepository(Delivery)
    private readonly deliveryRepo: Repository<Delivery>,
    @InjectRepository(Order)
    private readonly orderRepo: Repository<Order>,
  ) {}

  findAll() {
    return this.deliveryRepo.find({
      relations: ['order', 'order.user'],
      order: { createdAt: 'DESC' },
    });
  }

  findById(uuid: string) {
    return this.deliveryRepo.findOne({
      where: { uuid },
      relations: ['order', 'order.user'],
    });
  }

  async createDelivery(order: Order) {
  const delivery = this.deliveryRepo.create({
    order,
    address: order.user.address, // ✅ ahora sí existe
    phoneNumber: order.user.phone, // ✅ nombre correcto
  });

  return await this.deliveryRepo.save(delivery);
}


  async updateStatus(delivery: Delivery, status: DeliveryStatus) {
    delivery.status = status;

    if (status === DeliveryStatus.SHIPPED) {
      delivery.shippedAt = new Date();
    }

    if (status === DeliveryStatus.DELIVERED) {
      delivery.deliveredAt = new Date();
    }

    return this.deliveryRepo.save(delivery);
  }
}

import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService, DataLoaderUsers } from './app.service';

import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { JwtModule } from '@nestjs/jwt';

import typeorm from './config/typeorm';

/* ===== ENTIDADES BASE (GLOBALES) ===== */
import { User } from './entities/users.entity';
import { Credential } from './entities/credential.entity';

/* ===== MÓDULOS ===== */
import { AuthModule } from './auth/auth.module';
import { UserModule } from './users/users.module';
import { CredentialModule } from './credential/credential.module';
import { ProductsModule } from './products/products.module';
import { CategoriesModule } from './categories/categories.module';
import { CartModule } from './cart/cart.module';
import { OrderModule } from './order/order.module';
import { OrderDetailModule } from './orderdetail/orderdetail.module';
import { PaymentModule } from './payment/payment.module';
import { SubscriptionModule } from './subscription/subscription.module';
import { PlanModule } from './plan/plan.module';
import { WorkoutModule } from './workout/workout.module';
import { ProgressModule } from './progress/progress.module';
import { ConsultationModule } from './consultation/consultation.module';
import { ProfessionalModule } from './professional/professional.module';
import { SupportModule } from './support/support.module';
import { NutritionModule } from './nutrition/nutrition.module';

@Module({
  imports: [
    /* ===== CONFIG GLOBAL ===== */
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env.development',
      load: [typeorm],
    }),

    /* ===== TYPEORM ===== */
    TypeOrmModule.forRootAsync({
  inject: [ConfigService],
  useFactory: (config: ConfigService): TypeOrmModuleOptions => {
    return config.getOrThrow<TypeOrmModuleOptions>('typeorm');
  },
}),

    /* ===== JWT ===== */
    JwtModule.register({
      global: true,
      secret: process.env.JWT_SECRET,
      signOptions: { expiresIn: '1h' },
    }),

    /* ===== ENTIDADES GLOBALES (OPCIONAL) ===== */
    TypeOrmModule.forFeature([User, Credential]),

    /* ===== DOMINIOS ===== */
    UserModule,
    AuthModule,
    CredentialModule,
    ProductsModule,
    CategoriesModule,
    CartModule,
    OrderModule,
    OrderDetailModule,
    PaymentModule,
    SubscriptionModule,
    PlanModule,
    NutritionModule,
    WorkoutModule,
    ProgressModule,
    ConsultationModule,
    ProfessionalModule,
    SupportModule,
  ],
  controllers: [AppController],
  providers: [AppService, DataLoaderUsers],
})
export class AppModule {}

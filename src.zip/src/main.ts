import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe, Logger } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { loggerGlobal } from './middelwares/loggerGlobal';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  const logger = new Logger('Bootstrap');

  // Middleware global
  app.use(loggerGlobal);

  // Prefijo global para API (BUENA PRÁCTICA)
  app.setGlobalPrefix('api');

  // Validaciones globales
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  // Swagger
  const config = new DocumentBuilder()
    .setTitle('Bienestar Online API')
    .setDescription(
      'API para gestión de bienestar, nutrición, rutinas, suscripciones y tienda',
    )
    .setVersion('1.0')
    .addBearerAuth(
      {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        in: 'header',
      },
      'access-token',
    )
    .build();

  const document = SwaggerModule.createDocument(app, config);

  SwaggerModule.setup('api/docs', app, document);

  const port = process.env.PORT || 3002;
  await app.listen(port);

  logger.log(`🚀 Servidor corriendo en http://localhost:${port}`);
  logger.log(`📘 Swagger disponible en http://localhost:${port}/api/docs`);
}

bootstrap();

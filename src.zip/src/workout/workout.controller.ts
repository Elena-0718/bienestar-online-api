// workout.controller.ts
import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Delete,
} from '@nestjs/common';
import { WorkoutService } from './workout.service';
import { CreateWorkoutPlanDto } from './dtos/create-workout-plan.dto';
import { UpdateWorkoutPlanDto } from './dtos/update-workout-plan.dto';


@Controller('workouts')
export class WorkoutController {
  constructor(private readonly workoutService: WorkoutService) {}

  @Post()
  create(@Body() dto: CreateWorkoutPlanDto) {
    return this.workoutService.create(dto);
  }

  @Get('user/:userId')
  findByUser(@Param('userId') userId: string) {
    return this.workoutService.findByUser(userId);
  }

  @Get(':uuid')
  findOne(@Param('uuid') uuid: string) {
    return this.workoutService.findOne(uuid);
  }

  @Patch(':uuid')
  update(
    @Param('uuid') uuid: string,
    @Body() dto: UpdateWorkoutPlanDto,
  ) {
    return this.workoutService.update(uuid, dto);
  }

  @Delete(':uuid')
  deactivate(@Param('uuid') uuid: string) {
    return this.workoutService.deactivate(uuid);
  }
}

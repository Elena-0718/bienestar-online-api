// workout.service.ts
import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { WorkoutRepository } from './workout.repository';
import { SubscriptionRepository } from 'src/subscription/subscription.repository';
import { ProfessionalRepository } from 'src/professional/professional.repository';
import { WorkoutPlan } from 'src/entities/workout.entity';
import { CreateWorkoutPlanDto } from './dtos/create-workout-plan.dto';
import { UpdateWorkoutPlanDto } from './dtos/update-workout-plan.dto';

@Injectable()
export class WorkoutService {
  constructor(
    private readonly workoutRepo: WorkoutRepository,
    private readonly subscriptionRepo: SubscriptionRepository,
    private readonly professionalRepo: ProfessionalRepository,
  ) {}

  /* =========================
     CREATE
  ========================== */
  async create(dto: CreateWorkoutPlanDto): Promise<WorkoutPlan> {
    const subscription =
      await this.subscriptionRepo.getActiveSubscriptionByUser(dto.userId);

    if (!subscription) {
      throw new BadRequestException(
        'El usuario no tiene una suscripción activa',
      );
    }

    const professional = await this.professionalRepo.findOne({
      where: { uuid: dto.professionalId },
    });

    if (!professional) {
      throw new NotFoundException('Profesional no encontrado');
    }

    const workout = await this.workoutRepo.createWorkoutPlan({
      subscription,
      professional,
      objective: dto.objective,
      notes: dto.notes,
      weeklyRoutine: dto.weeklyRoutine, // ✅ JSONB correcto
      isActive: dto.isActive ?? true,
    });

    return workout;
  }

  /* =========================
     FIND ALL BY SUBSCRIPTION
  ========================== */
  async findByUser(userUuid: string): Promise<WorkoutPlan[]> {
    const subscription =
      await this.subscriptionRepo.getActiveSubscriptionByUser(userUuid);

    if (!subscription) {
      throw new NotFoundException('Suscripción activa no encontrada');
    }

    return this.workoutRepo.findBySubscription(subscription.uuid);
  }

  /* =========================
     FIND ONE
  ========================== */
  async findOne(uuid: string): Promise<WorkoutPlan> {
    const workout = await this.workoutRepo.findOne({
      where: { uuid },
    });

    if (!workout) {
      throw new NotFoundException('Plan de entrenamiento no encontrado');
    }

    return workout;
  }

  /* =========================
     UPDATE
  ========================== */
  async update(
    uuid: string,
    dto: UpdateWorkoutPlanDto,
  ): Promise<WorkoutPlan> {
    const workout = await this.findOne(uuid);

    Object.assign(workout, dto);

    return this.workoutRepo.save(workout);
  }

  /* =========================
     DELETE (SOFT LOGIC)
  ========================== */
  async deactivate(uuid: string): Promise<WorkoutPlan> {
    const workout = await this.findOne(uuid);

    workout.isActive = false;

    return this.workoutRepo.save(workout);
  }
}

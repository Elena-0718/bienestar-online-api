// workout.repository.ts
import { Injectable } from '@nestjs/common';
import { DataSource, Repository } from 'typeorm';
import { WorkoutPlan } from 'src/entities/workout.entity';

@Injectable()
export class WorkoutRepository extends Repository<WorkoutPlan> {
  constructor(private readonly dataSource: DataSource) {
    super(WorkoutPlan, dataSource.createEntityManager());
  }

  async createWorkoutPlan(data: Partial<WorkoutPlan>): Promise<WorkoutPlan> {
    const workout = this.create(data);
    return this.save(workout);
  }

  async findBySubscription(subscriptionUuid: string): Promise<WorkoutPlan[]> {
    return this.find({
      where: {
        subscription: { uuid: subscriptionUuid },
      },
      order: { createdAt: 'DESC' },
    });
  }

  async findActiveBySubscription(
    subscriptionUuid: string,
  ): Promise<WorkoutPlan | null> {
    return this.findOne({
      where: {
        subscription: { uuid: subscriptionUuid },
        isActive: true,
      },
    });
  }
}
5